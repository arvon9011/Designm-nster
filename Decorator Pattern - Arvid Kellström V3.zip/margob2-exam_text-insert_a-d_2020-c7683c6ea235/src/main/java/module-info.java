module textinserter {
    requires javafx.controls;
    requires javafx.graphics;
    requires javafx.fxml;

    opens controllers;
    opens files;
    opens textinserter;
}