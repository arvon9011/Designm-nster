package files;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;

public class BaseSixtyFour extends Encrypt {



    public BaseSixtyFour(IMessageSaver mess) {
        super(mess);
    }

    @Override
    public String saveMessage(String message) throws Exception {
      return super.saveMessage(encryptMessage(message));
    }

    private String encryptMessage(String message) {
        String encodedString = Base64.getEncoder().encodeToString(message.getBytes());
        return encodedString;
    }
}
