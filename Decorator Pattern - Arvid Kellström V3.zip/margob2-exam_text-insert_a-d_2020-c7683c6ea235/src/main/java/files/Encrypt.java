package files;

public abstract class Encrypt implements IMessageSaver{

    private IMessageSaver text;

    public Encrypt (IMessageSaver mess){this.text = mess;}

    @Override
    public String saveMessage(String message) throws Exception {
        return this.text.saveMessage(message);
    }


}
