package files;

public class SuperImplementation extends Encrypt{





    public SuperImplementation(IMessageSaver mess) {
        super(mess);
    }

    @Override
    public String saveMessage(String message) throws Exception {

        return super.saveMessage(encryptMessage(message));
    }

    private String encryptMessage(String message){



        String outString = "";

        int length = message.length();
        for (int i = 0; i < length; i++) {
            String currentLetter = message.toLowerCase().charAt(i) + "";
            if (currentLetter.contains("e")) { outString += "3"; }

          else  if (currentLetter.contains("a")) { outString += "4"; }

            else  if (currentLetter.contains("b")) { outString += "I3"; }

            else  if (currentLetter.contains("b")) { outString += "©"; }

            else  if (currentLetter.contains("d")) { outString += "[)"; }

            else  if (currentLetter.contains("v")) { outString += "|/"; }

          else  if (currentLetter.contains("t")) { outString += "7"; }

           else if (currentLetter.contains("i") || currentLetter.contains("l")) { outString += "1"; }


            else {
                outString += message.charAt(i);
            }
        }
        return outString;
    }


}
