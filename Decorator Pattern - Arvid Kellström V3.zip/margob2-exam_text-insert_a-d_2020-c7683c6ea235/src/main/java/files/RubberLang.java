package files;

import java.nio.file.Path;
import java.nio.file.Paths;

public class RubberLang extends Encrypt {



    public RubberLang(IMessageSaver mess) {
        super(mess);
    }

    @Override
    public String saveMessage(String message) throws Exception {

        return super.saveMessage(encryptMessage((message)));

    }

    private String encryptMessage(String message){
        String vowels = "aeyuoåäöi";
        String outString = "";
        int length = message.length();
        for (int i = 0; i < length; i++) {
            if (vowels.contains(message.toLowerCase().charAt(i) + "")) {
                char c = message.charAt(i);
                outString += c + "o" + c;
            } else {
                outString += message.charAt(i);
            }
        }

        return outString;
    }


}
