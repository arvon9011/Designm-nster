package controllers;

public interface Observer {


    public void update();

}
