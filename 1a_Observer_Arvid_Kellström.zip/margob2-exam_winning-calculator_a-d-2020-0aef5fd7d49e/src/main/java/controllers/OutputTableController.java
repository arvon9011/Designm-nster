package controllers;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import state.StateStore;


public class OutputTableController implements Initializable, Observer {

    @FXML
    private Label lblWinning;
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        StateStore.getInstance().registerObserver(this);
        value();

    }

    public void value (){
        lblWinning.setText(String.valueOf(StateStore.getInstance().getState().getOutWinningCalc()));
    }

    @Override
    public void update() {
        value();
    }
}
