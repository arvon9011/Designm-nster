package tealistfileconverter;

import tealistfileconverter.TeaListFileConverter;
import tealistfileconverter.converters.TeaListConverter;
import tealistfileconverter.converters.TeaListConverterCsv;
import tealistfileconverter.converters.TeaListConverterDsv;
import tealistfileconverter.converters.TeaListConverterXml;

public class ConvertToFactory implements IConverterFactory {

    @Override
    public TeaListConverter chooseConverterFrom(String value) {
        return null;
    }

    @Override
    public TeaListConverter chooseConverterTo(String value) {
        TeaListConverter tlc = null;
        if (value.equals("csv")) {
            tlc =  new TeaListConverterCsv();
        } else if (value.equals("dsv")) {
            tlc = new TeaListConverterDsv();
        }

        else if (value.equals("xml")) {
            tlc = new TeaListConverterXml();
        }
        return tlc;

    }
}

