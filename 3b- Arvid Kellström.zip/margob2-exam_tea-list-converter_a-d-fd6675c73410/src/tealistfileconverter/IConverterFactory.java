package tealistfileconverter;

import tealistfileconverter.converters.TeaListConverter;

public interface IConverterFactory {

    TeaListConverter chooseConverterFrom(String value);
    TeaListConverter chooseConverterTo(String value);
}
